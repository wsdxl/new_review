"""
Author:dxl
Time: 2020/8/30 15:08
File: test.py
"""
receivers = ['542925725@qq.com', 'zyqkenmy@126.com']
msg=','.join(receivers)
print(msg,type(msg))